<?php

/*
 * PuzzleApp
 * Webemyos
 * Jérôme Oliva
 * GNU Licence
 */

namespace Core\Control\Icone;


/**
 * icone type liste
 */
class ListIcone extends Icone
{
    function __construct()
    {
        $this->CssClass = "fa fa-list";
    }
}

