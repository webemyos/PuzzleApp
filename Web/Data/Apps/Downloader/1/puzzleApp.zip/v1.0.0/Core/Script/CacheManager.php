<?php

/*
 * PuzzleApp
 * Webemyos
 * Jérôme Oliva
 * GNU Licence
 */

namespace Core\Script;

/**
 * Description of CacheManager
 *
 * @author jerome
 */
class CacheManager 
{
    /*
     * Find Script in the Cache
     */
    public static function Find($file)
    {
        return null;
    }
}
