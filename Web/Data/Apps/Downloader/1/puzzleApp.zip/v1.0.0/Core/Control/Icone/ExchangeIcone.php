<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Core\Control\Icone;

/*
* Icone dechange
*/
class ExchangeIcone extends Icone
{
    function __construct()
    {
        $this->CssClass = "fa fa-exchange";
    }
}
