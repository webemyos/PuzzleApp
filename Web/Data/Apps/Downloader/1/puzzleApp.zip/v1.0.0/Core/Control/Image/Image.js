ShowImage = function(image)
{
var imageControl = document.getElementById("ImagePrincipale");
imageControl.src = image.src;
};