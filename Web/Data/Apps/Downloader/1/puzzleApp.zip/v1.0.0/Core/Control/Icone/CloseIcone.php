<?php

/*
 * PuzzleApp
 * Webemyos
 * Jérôme Oliva
 * GNU Licence
 */

namespace Core\Control\Icone;

/**
 * Description of CloseIcone
 *
 * @author jerome
 */
/*
* Icone de fermeture
*/
class CloseIcone extends Icone
{
    function CloseIcone()
    {
            $this->CssClass = "icon-off";
    }
}
