<?php

/*
 * PuzzleApp
 * Webemyos
 * Jérôme Oliva
 * GNU Licence
 */

namespace Core\Entity\Entity;

/**
 * Description of Select
 *
 * @author OLIVA
 */
class Select {
    //put your code here
}
