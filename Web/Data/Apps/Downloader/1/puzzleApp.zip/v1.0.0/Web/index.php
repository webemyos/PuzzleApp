<?php

/*
 * PuzzleApp
 * Webemyos
 * Jérôme Oliva
 * GNU Licence
 */

include("../autoload.php");
include("../Core/Runner.php");
Runner::Run("Base", "dev", false);

?>
